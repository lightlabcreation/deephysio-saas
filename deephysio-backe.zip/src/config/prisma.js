const { PrismaClient } = require('@prisma/client');
const tenantContext = require('./tenantContext');

const prisma = new PrismaClient().$extends({
  query: {
    $allModels: {
      async $allOperations({ model, operation, args, query }) {
        const tenantId = tenantContext.getStore();

        // Models that DO NOT have tenant_id
        const tenantFreeModels = ['Tenant', 'User']; // We handle User tenant_id manually during auth

        if (tenantId && !tenantFreeModels.includes(model)) {
          if (['findMany', 'findFirst', 'findUnique', 'count', 'deleteMany', 'updateMany'].includes(operation)) {
            args.where = { ...args.where, tenant_id: tenantId };
          }
          if (['create', 'createMany'].includes(operation)) {
            if (args.data) {
              if (Array.isArray(args.data)) {
                args.data = args.data.map(d => ({ ...d, tenant_id: tenantId }));
              } else {
                args.data.tenant_id = tenantId;
              }
            }
          }
          if (operation === 'update') {
            args.where = { ...args.where, tenant_id: tenantId };
            if (args.data) args.data.tenant_id = tenantId;
          }
        }
        
        return query(args);
      }
    }
  }
});

module.exports = prisma;
