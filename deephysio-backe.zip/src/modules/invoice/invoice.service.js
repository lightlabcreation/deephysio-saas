const prisma = require('../../config/prisma');

const INVOICE_NUMBER_PREFIX = 'DEEPHYSIO-';

/** @param {number} seq 1-based sequence */
const formatInvoiceNumber = (seq) => {
  const n = Number(seq);
  if (!Number.isFinite(n) || n < 1) {
    throw new Error('Invalid invoice sequence');
  }
  const s = String(Math.floor(n));
  const width = Math.max(4, s.length);
  return `${INVOICE_NUMBER_PREFIX}${s.padStart(width, '0')}`;
};

const invoiceNumberRegex = new RegExp(
  `^${INVOICE_NUMBER_PREFIX.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\d+)$`
);

/**
 * @param {import('@prisma/client').Prisma.TransactionClient | typeof prisma} tx
 */
const getMaxInvoiceSequence = async (tx) => {
  const rows = await tx.invoice.findMany({
    where: { invoice_number: { startsWith: INVOICE_NUMBER_PREFIX } },
    select: { invoice_number: true }
  });
  let max = 0;
  for (const r of rows) {
    const m = r.invoice_number && invoiceNumberRegex.exec(r.invoice_number);
    if (m) max = Math.max(max, parseInt(m[1], 10));
  }
  return max;
};

const getAllInvoices = async (filters) => {
  const { status, patientId } = filters;
  const where = {};

  if (status) where.status = status;
  if (patientId) where.patient_id = parseInt(patientId, 10);

  return await prisma.invoice.findMany({
    where,
    include: {
      patient: { select: { id: true, first_name: true, last_name: true } },
      items: true,
      payments: true
    },
    orderBy: { created_at: 'desc' }
  });
};

const getInvoiceById = async (id) => {
  const invoice = await prisma.invoice.findUnique({
    where: { id },
    include: {
      patient: { select: { id: true, first_name: true, last_name: true } },
      items: true,
      payments: true
    }
  });

  if (!invoice) {
    const error = new Error('Invoice not found');
    error.statusCode = 404;
    throw error;
  }

  return invoice;
};

const getInvoiceDownloadPayload = async (id) => {
  const invoice = await getInvoiceById(id);
  return {
    id: invoice.id,
    invoice_number: invoice.invoice_number,
    patient: invoice.patient,
    date: invoice.date,
    subtotal: invoice.subtotal,
    tax: invoice.tax,
    total: invoice.total,
    status: invoice.status,
    notes: invoice.notes,
    items: invoice.items || [],
    payments: invoice.payments || [],
    generated_at: new Date().toISOString()
  };
};

const createInvoice = async (data) => {
  const { patientId, date, items, notes } = data;

  let taxRate = 20;
  try {
    const settings = await prisma.globalSettings.findUnique({ where: { key: 'clinicProfile' } });
    if (settings && settings.value) {
      const profile = JSON.parse(settings.value);
      if (profile.taxRate !== undefined) taxRate = Number(profile.taxRate);
    }
  } catch (e) {
    console.error('Failed to fetch tax settings');
  }

  let subtotal = 0;
  items.forEach((item) => {
    subtotal += item.rate * item.qty;
  });
  const tax = subtotal * (taxRate / 100);
  const total = subtotal + tax;

  const MAX_RETRY = 12;
  let lastErr;
  for (let attempt = 0; attempt < MAX_RETRY; attempt += 1) {
    try {
      return await prisma.$transaction(async (tx) => {
        const maxSeq = await getMaxInvoiceSequence(tx);
        const invoice_number = formatInvoiceNumber(maxSeq + 1);
        return tx.invoice.create({
          data: {
            invoice_number,
            patient_id: patientId,
            date: new Date(date),
            subtotal,
            tax,
            total,
            notes,
            status: 'PENDING',
            items: {
              create: items.map((item) => ({
                service: item.service,
                rate: item.rate,
                qty: item.qty
              }))
            }
          },
          include: {
            items: true,
            patient: true
          }
        });
      });
    } catch (e) {
      lastErr = e;
      if (e?.code === 'P2002') continue;
      throw e;
    }
  }
  throw lastErr || new Error('Could not allocate unique invoice number');
};

const deleteInvoice = async (id) => {
  const invoice = await prisma.invoice.findUnique({ where: { id } });
  if (!invoice) {
    const error = new Error('Invoice not found');
    error.statusCode = 404;
    throw error;
  }

  await prisma.invoiceItem.deleteMany({ where: { invoice_id: id } });
  await prisma.payment.deleteMany({ where: { invoice_id: id } });

  return await prisma.invoice.delete({ where: { id } });
};

module.exports = {
  getAllInvoices,
  getInvoiceById,
  getInvoiceDownloadPayload,
  createInvoice,
  deleteInvoice
};
