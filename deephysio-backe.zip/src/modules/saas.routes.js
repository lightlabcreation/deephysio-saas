const express = require('express');
const router = express.Router();
const { verifyToken } = require('./auth/auth.middleware');
const saasState = require('../config/saasState');

router.get('/revenue', verifyToken, (req, res) => {
  return res.status(200).json({
    success: true,
    data: saasState.getRevenueStats()
  });
});

router.get('/payments', verifyToken, (req, res) => {
  return res.status(200).json({
    success: true,
    data: saasState.getPayments()
  });
});

router.get('/tenants', verifyToken, async (req, res) => {
  try {
    const prisma = require('../config/prisma');
    const tenants = await prisma.tenant.findMany({
      include: {
        users: {
          where: { role: 'admin' },
          take: 1
        }
      },
      orderBy: { created_at: 'desc' }
    });

    const mappedTenants = tenants.map(t => {
      const admin = t.users[0] || {};
      return {
        id: t.id,
        name: admin.name || 'Unknown Admin',
        email: t.email || admin.email,
        plan: t.plan || 'Starter',
        expiry_date: new Date(new Date(t.created_at).setFullYear(new Date(t.created_at).getFullYear() + 1)).toISOString(),
        clinic_name: t.clinic_name || 'N/A',
        subscription_status: t.subscription_status || 'active',
        phone: admin.phone || 'N/A'
      };
    });

    return res.status(200).json({
      success: true,
      data: mappedTenants
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

let mockSettings = {
  profile: { name: 'Super Admin', email: 'superadmin@deephysio.com', photo: '' },
  business: { businessName: 'DeePhysio Global', gstNumber: '29ABCDE1234F2Z5', mobileNumber: '+91 9876543210', businessAddress: 'Bangalore, India' },
  notifications: {}
};

router.get('/settings', verifyToken, (req, res) => {
  return res.status(200).json({ success: true, data: mockSettings });
});

router.put('/settings', verifyToken, (req, res) => {
  if (req.body.profile) mockSettings.profile = { ...mockSettings.profile, ...req.body.profile };
  if (req.body.business) mockSettings.business = { ...mockSettings.business, ...req.body.business };
  if (req.body.notifications) mockSettings.notifications = { ...mockSettings.notifications, ...req.body.notifications };
  
  return res.status(200).json({ success: true, message: 'Settings updated successfully' });
});

router.put('/settings/password', verifyToken, (req, res) => {
  // In a real flow, this would check bcrypt hash and update Prisma DB.
  // We mock success here for UI flow demonstration.
  return res.status(200).json({ success: true, message: 'Password updated successfully' });
});

router.patch('/tenants/:id/status', verifyToken, async (req, res) => {
  try {
    const prisma = require('../config/prisma');
    const { status } = req.body;
    await prisma.tenant.update({
      where: { id: parseInt(req.params.id, 10) },
      data: { subscription_status: status }
    });
    return res.status(200).json({ success: true, message: 'Status updated' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/tenants/:id', verifyToken, async (req, res) => {
  try {
    const prisma = require('../config/prisma');
    // Delete associated users first
    await prisma.user.deleteMany({
      where: { tenant_id: parseInt(req.params.id, 10) }
    });
    await prisma.tenant.delete({
      where: { id: parseInt(req.params.id, 10) }
    });
    return res.status(200).json({ success: true, message: 'Tenant deleted' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
