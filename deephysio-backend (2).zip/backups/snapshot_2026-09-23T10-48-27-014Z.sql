-- DeePhysio Database Disaster Recovery SQL Dump
-- Created At: 2026-09-23T10:48:27.020Z
-- Tenant Scope: ALL TENANTS (GLOBAL)

-- Table: Tenant (5 records)
INSERT INTO "Tenant" ("id", "clinic_name", "email", "subscription_status", "created_at") VALUES (1, 'deephysio ', 'sasxs@gmail.com', 'active', NOW()) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Tenant" ("id", "clinic_name", "email", "subscription_status", "created_at") VALUES (2, 'ABC CLINIC', 'abc@gmail.com', 'trial', NOW()) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Tenant" ("id", "clinic_name", "email", "subscription_status", "created_at") VALUES (3, 'Saanu''s Clinic', 'saanu@gmail.com', 'active', NOW()) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Tenant" ("id", "clinic_name", "email", "subscription_status", "created_at") VALUES (4, 'Santu''s Clinic', 'santu@gmail.com', 'canceled', NOW()) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Tenant" ("id", "clinic_name", "email", "subscription_status", "created_at") VALUES (5, 'Sanuh''s Clinic', 'sanu@gmail.com', 'active', NOW()) ON CONFLICT ("id") DO NOTHING;

-- Table: Service (3 records)
INSERT INTO "Service" ("id", "name", "category", "duration", "price", "is_active", "tenant_id") VALUES (1, 'body therapy', 'General', 30, 50, TRUE, NULL) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Service" ("id", "name", "category", "duration", "price", "is_active", "tenant_id") VALUES (2, 'demo', 'General', 45, 500, TRUE, 1) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Service" ("id", "name", "category", "duration", "price", "is_active", "tenant_id") VALUES (3, 'Hand facture', 'Manual Therapy', 30, 900, TRUE, 1) ON CONFLICT ("id") DO NOTHING;

-- Table: Patient (9 records)
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (1, 'first', 'patient', '1234567890', 'first@gmail.com', 'other', NULL) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (2, 'patient', '01', '1234567897', 'patient01@gmail.com', 'male', NULL) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (3, 'harhub', 'json', '78736627348', 'harhub@gmail.com', 'male', NULL) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (4, 'sasa', 'sasa', '3234445454', 'dssd@gmail.com', 'male', 1) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (5, 'testing', '01', '97556867556', 'testing@gmail.com', 'male', 1) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (8, 'Mobile', 'Test', '648794849', 'mobile@gmail.com', 'male', 1) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (9, 'Snsjns', 'Nsnsn', '94986494815', 'dhsh@gmail.com', 'male', 1) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (10, 'Sat', 'Gos', '564879485', 'sat@gmail.com', 'male', 1) ON CONFLICT ("id") DO NOTHING;
INSERT INTO "Patient" ("id", "first_name", "last_name", "phone", "email", "gender", "tenant_id") VALUES (11, 'Test', 'Ing', '98784589', 'testingj@gmail.com', 'male', 1) ON CONFLICT ("id") DO NOTHING;

